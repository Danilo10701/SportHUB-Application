import SwiftUI

@main
struct SportHUBApp: App {
    var body: some Scene {
        WindowGroup {
            SHTabsRootView()
        }
    }
}
